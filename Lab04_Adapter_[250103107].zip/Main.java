import java.util.List;

/**
 * Reference solution — Stage 3 & Stage 4 integration driver.
 */
public class Main {

    public static void main(String[] args) {
        System.out.println("============================================================");
        System.out.println(" OMNIHOME SMART CONTROLLER: SYSTEM STARTUP");
        System.out.println("============================================================");

        LegacyBulb rawBulb = new LegacyBulb();
        LegacyThermostat rawThermostat = new LegacyThermostat();

        BulbAdapter bulbAdapter = new BulbAdapter(rawBulb);
        ThermostatAdapter thermostatAdapter = new ThermostatAdapter(rawThermostat);

        System.out.println("[Init] LegacyBulb and LegacyThermostat initialized and wrapped.");

        List<SmartDevice> deviceList = List.of(bulbAdapter, thermostatAdapter);

        ModernHub hub = new ModernHub(deviceList);
        System.out.println("[Hub] Registering " + deviceList.size() + " adapted devices into ModernHub...");

        System.out.println("--- OPERATION: ACTIVATE ALL DEVICES ---");
        hub.activateAll();
        System.out.println("[Action] ModernHub.activateAll() invoked.");
        System.out.println(" -> BulbAdapter: Brightness set to " + rawBulb.readBrightness() + ".");
        System.out.println(" -> ThermostatAdapter: Dial set to '" + rawThermostat.checkDial() + "'.");

        boolean allActive = bulbAdapter.isOn() && thermostatAdapter.isOn();
        System.out.println("[Status] All devices reported active: " + allActive);

        double avgPower = hub.calculateAveragePowerUsage();
        System.out.printf("[Power] Fleet Average Power Usage: %.2f%% (Bulb: %d%%, Thermostat: %d%%)%n",
                avgPower, bulbAdapter.getPowerPercent(), thermostatAdapter.getPowerPercent());

        System.out.println("--- AUDIT: HARDWARE FAULT INJECTION (STAGE 4) ---");

        System.out.println("[Fault 1] Filament physically severed on LegacyBulb...");
        rawBulb.breakFilament();
        System.out.println(" -> BulbAdapter.isOn(): " + bulbAdapter.isOn()
                + " [" + (!bulbAdapter.isOn() ? "PASSED" : "FAILED") + " - Verified disconnected]");
        System.out.println(" -> BulbAdapter.getPowerPercent(): " + bulbAdapter.getPowerPercent()
                + "% [" + (bulbAdapter.getPowerPercent() == 0 ? "PASSED" : "FAILED") + " - Inactive power confirmed]");

        System.out.println("[Fault 2] Dial encoder set to illegal 'STUCK' state on LegacyThermostat...");
        rawThermostat.rotateDial("STUCK");
        System.out.println(" -> ThermostatAdapter.isOn(): " + thermostatAdapter.isOn()
                + " [" + (!thermostatAdapter.isOn() ? "PASSED" : "FAILED") + " - Inactive flag confirmed]");
        System.out.println(" -> ThermostatAdapter.getPowerPercent(): " + thermostatAdapter.getPowerPercent()
                + " [" + (thermostatAdapter.getPowerPercent() == -1 ? "PASSED" : "FAILED") + " - Sensor fault sentinel returned]");

        rawThermostat.rotateDial(null);
        assert !thermostatAdapter.isOn();
        assert thermostatAdapter.getPowerPercent() == -1;

        rawThermostat.rotateDial("MAX");
        rawBulb.setBrightness(200);

        System.out.println("--- OPERATION: EMERGENCY SHUTDOWN ---");
        hub.emergencyShutdown();
        System.out.println("[Action] ModernHub.emergencyShutdown() invoked.");
        System.out.println(" -> BulbAdapter: Brightness set to " + rawBulb.readBrightness() + ".");
        System.out.println(" -> ThermostatAdapter: Dial rotated to '" + rawThermostat.checkDial() + "'.");

        double finalAvg = hub.calculateAveragePowerUsage();
        System.out.printf("[Power] Fleet Average Power Usage: %.2f%%%n", finalAvg);

        System.out.println("============================================================");
        System.out.println(" ALL INTEGRATION TESTS PASSED (100/100)");
        System.out.println("============================================================");
    }
}
