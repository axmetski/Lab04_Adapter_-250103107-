
public class BulbAdapter implements SmartDevice {

    private static final int K = 7;//250103107 mine

    private final LegacyBulb bulb;

    public BulbAdapter(LegacyBulb bulb) {
        if (bulb == null) {
            throw new IllegalArgumentException("LegacyBulb cannot be null");
        }
        this.bulb = bulb;
    }

    @Override
    public void turnOn() {
        bulb.setBrightness(255);
    }

    @Override
    public void turnOff() {
        bulb.setBrightness(0);
    }

    @Override
    public boolean isOn() {
        if (!bulb.hasPower()) {
            return false;
        }
        return bulb.readBrightness() > 0;
    }

    @Override
    public int getPowerPercent() {
        if (!bulb.hasPower()) {
            return 0;
        }

        int raw = bulb.readBrightness();
        if (raw == 0) {
            return 0;
        }

        int basePercent = (raw * 100) / 255;
        int calibratedPercent = basePercent + K;

        if (calibratedPercent > 100) {
            calibratedPercent = 100;
        }
        return calibratedPercent;
    }
}
